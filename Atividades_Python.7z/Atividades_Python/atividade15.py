entrada1 = int(input('Digite um numero: '))
entrada2 = int(input('Digite um numero: '))
entrada3 = int(input('Digite um numero: '))

maior = max (entrada1, entrada2, entrada3)

print('Maior número é:',maior)