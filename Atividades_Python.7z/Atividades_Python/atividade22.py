numero = int(input('Digite um numero: '))

for i in range(numero +1, 101):
    if(i%2 == 0):
        print(i)