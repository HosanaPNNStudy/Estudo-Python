numero = int(input('Digite um numero: '))

for i in range(numero, -1, -1):
    print(i)

for i in range(1,numero +1 , +1):
    print(i)
    